# Load libraries
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)

# Load data
setwd("C:/Users/Jonat/Desktop/Cpt_S 475/Project")
data <- read_csv("lungcancer_inc_per100k_pop_2015_2019_gender.csv")

# Create a new data frame with value converted to numeric
numeric_gender_data <- data %>%
  filter(!is.na(Gender)) %>%
  select(State, County, Gender, Value) %>%
  mutate(Value = as.numeric(Value))

# Create the bar plot
ggplot(numeric_gender_data, aes(x = State, y = ifelse(is.na(Value), 0, Value), fill = Gender)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Male vs. Female Lung Cancer by State",
       y = "Lung Cancer Value",
       x = "State") +
  scale_fill_manual(values = c("Male" = "blue", "Female" = "red")) +
  theme_minimal() +
  theme(legend.title = element_blank())

# Conclusion
cat("Based on observing the plot, we can see that in almost every state, male have higher lung cancer rates than female. The final conclusion is that male are more likely to get lung cancer than female.")

