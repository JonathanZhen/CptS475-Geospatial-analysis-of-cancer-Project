# Load necessary libraries
library(readr)
library(dplyr)
library(ggplot2)

# Load data
setwd("C:/Users/Jonat/Desktop/Cpt_S 475/Project")
data <- read_csv("lungcancer_inc_per100k_pop_2015_2019_race.csv")

# Clean and reshape the data
data_cleaned <- data %>%
  filter(!is.na(Value) & Value != "Suppressed") %>%
  select(State, County, `Race Ethnicity`, Value) %>%
  mutate(Value = as.numeric(Value))

# Create the bar plot
ggplot(data_cleaned, aes(x = `Race Ethnicity`, y = Value, fill = `Race Ethnicity`)) +
  geom_bar(stat = "identity") +
  labs(title = "Lung Cancer Incidence Rates by Race/Ethnicity",
       y = "Incidence Rate",
       x = "Race/Ethnicity") +
  theme_minimal() +
  theme(legend.position = "none")

# Conclusion
cat("Based on observing the plot, we can see that white people have the highest lung cancer prevalence rates, while Asians have the lowest. The final conclusion is that white people are more likely to get lung cancer than other races.")


