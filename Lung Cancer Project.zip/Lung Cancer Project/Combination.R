library(dplyr)
library(ggplot2)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(maps)

# Load data
setwd("C:/Users/Jonat/Desktop/Cpt_S 475/Project")

lung_cancer <- read.csv("lungcancer_inc_per100k_pop_2015_2019.csv")
air_quality <- read.csv("air_quality_pm2.5annualavg_bycounty_2018_2019.csv")

# Remove duplicates
lung_cancer <- lung_cancer %>% distinct(StateFIPS, CountyFIPS, County, .keep_all = TRUE)
air_quality <- air_quality %>% distinct(StateFIPS, CountyFIPS, County, .keep_all = TRUE)

# Merge the datasets based on common columns
merged_data0 <- merge(air_quality, lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Convert 'Value.y' to numeric
merged_data0$Value.y <- as.numeric(merged_data0$Value.y)

# Plot Value.x against Value.y
ggplot(merged_data0, aes(x = Value.x, y = Value.y)) +
  geom_point() +
  labs(title = "Comparison of Air Quality and Population",
       x = "Air Quality",
       y = "Population") +
  theme_minimal() +
  scale_y_continuous(breaks = seq(0, max(merged_data0$Value.y), by = 10))

#Conclusion
cat("By observing the plot, the level of air quality does not seem to directly affect the prevalence of lung cancer.")

#==================================================================================================

arsenic <- read.csv("arsenic_annual_mean_conc_2018_2019.csv")

# Merge datasets based on common columns
merged_data1 <- merge(arsenic, lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Plotting
ggplot(merged_data1, aes(x = Value.x, y = as.factor(Value.y))) +
  geom_boxplot() +
  labs(title = "Relationship Between Arsenic Levels and Lung Cancer Rates",
       x = "Arsenic Annual Mean Concentration (2018-2019)",
       y = "Lung Cancer Population") +
  theme_minimal()

# Chi-squared test for independence
chi_squared_test <- chisq.test(table(merged_data1$Value.x, merged_data1$Value.y))

# Display test results
print(chi_squared_test)

# Conclusion
cat("The chi-squared test results indicate a highly significant p-value (p-value < 2.2e-16). This suggests that there is a statistically significant association between arsenic levels and lung cancer rates. The chi-squared statistic is substantial (X-squared = 609398), indicating a strong deviation from independence.")
cat("The results imply that there is evidence to reject the null hypothesis that arsenic levels and lung cancer rates are independent. Therefore, there appears to be a relationship between the levels of arsenic and the incidence of lung cancer in the dataset.")

#==================================================================================================

alcohol <- read.csv("binge_drinking_alcohol_adults_per100k_pop_2018_2019.csv")

# Merge datasets based on common columns
merged_data2 <- merge(alcohol, lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Value.y conversion to numeric
merged_data2$Value.y <- as.numeric(merged_data2$Value.y)

# Plotting
ggplot(merged_data2, aes(x = log(Value.y), y = Value.x)) +
  geom_point() +
  labs(title = "Relationship Between Alcohol Consumption and Lung Cancer Rates",
       x = "Log Alcohol Consumption (2015-2019)",
       y = "Lung Cancer Rate") +
  scale_x_continuous(labels = scales::number_format(scale = 0.1, suffix = "%")) +
  theme_minimal()

# Conclusion
cat("The scatter plot visually depicts the relationship between alcohol consumption and lung cancer incidence rates.")
cat("The correlation coefficient indicates the strength and direction of the linear relationship.")
cat("A positive correlation suggests that higher alcohol consumption is associated with higher lung cancer rates.")
cat("Between 0.4% and 0.45%, the scatter points will be more densely distributed.Nonetheless, this does not necessarily mean that alcohol is the leading cause of lung cancer, and more information is needed.")

#==================================================================================================

heart_disease <- read.csv("coronary_heart_disease_per100k_pop_2018_2019.csv")
asthma <- read.csv("county_asthma_per100k_pop_2018_2019.csv")
diabetes <- read.csv("diabetes_adults_per100k_pop_2018_2019.csv")

# Merge datasets
merged_data5 <- heart_disease %>%
  left_join(asthma, by = c("StateFIPS", "CountyFIPS", "County", "Year")) %>%
  left_join(diabetes, by = c("StateFIPS", "CountyFIPS", "County", "Year")) %>%
  left_join(lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Convert columns to numeric
merged_data5$Value.x.x <- as.numeric(merged_data5$Value.x.x)
merged_data5$Value.y <- as.numeric(merged_data5$Value.y)
merged_data5$Value.x <- as.numeric(merged_data5$Value.x)
merged_data5$Value.y.y <- as.numeric(merged_data5$Value.y.y)

# Fit regression lines
fit_heart_disease <- lm(Value.y ~ Value.x.x, data = merged_data5)
fit_asthma <- lm(Value.y.y ~ Value.x, data = merged_data5)
fit_diabetes <- lm(Value.y ~ Value.y.y, data = merged_data5)

# Plot the relationship for Heart Disease
ggplot(merged_data5, aes(x = Value.x.x, y = Value.y, color = factor(State.x))) +
  geom_point(size = 3, alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE, formula = y ~ x, color = "black", data = merged_data5) +
  labs(title = "Relationship Between Heart Disease and Lung Cancer Prevalence",
       x = "Heart Disease Prevalence",
       y = "Lung Cancer Prevalence",
       color = "State") +
  theme_minimal() +
  facet_wrap(~ Data.Comment.x.x, scales = "free_y")

# Plot the relationship for Asthma
ggplot(merged_data5, aes(x = Value.x, y = Value.y.y, color = factor(State.y))) +
  geom_point(size = 3, alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE, formula = y ~ x, color = "black", data = merged_data5) +
  labs(title = "Relationship Between Asthma and Lung Cancer Prevalence",
       x = "Asthma Prevalence",
       y = "Lung Cancer Prevalence",
       color = "State") +
  theme_minimal() +
  facet_wrap(~ Data.Comment.y, scales = "free_y")

# Plot the relationship for Diabetes
ggplot(merged_data5, aes(x = Value.y.y, y = Value.y, color = factor(State.x.x))) +
  geom_point(size = 3, alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE, formula = y ~ x, color = "black", data = merged_data5) +
  labs(title = "Relationship Between Diabetes and Lung Cancer Prevalence",
       x = "Diabetes Prevalence",
       y = "Lung Cancer Prevalence",
       color = "State") +
  theme_minimal() +
  facet_wrap(~ Data.Comment.x.x, scales = "free_y")

# Calculate correlation coefficients
cor_heart_disease <- cor(merged_data5$Value.x.x, merged_data5$Value.y, use = "complete.obs")
cor_asthma <- cor(merged_data5$Value.x, merged_data5$Value.y.y, use = "complete.obs")
cor_diabetes <- cor(merged_data5$Value.y.y, merged_data5$Value.y, use = "complete.obs")

# Print correlation coefficients
cat("Correlation Heart Disease and Lung Cancer:", cor_heart_disease, "\n")
cat("Correlation Asthma and Lung Cancer:", cor_asthma, "\n")
cat("Correlation Diabetes and Lung Cancer:", cor_diabetes, "\n")

# Conclusion
cat("Each point corresponds to a specific county, and colors represent different diseases.")
cat("The scatter plot aims to identify any noticeable patterns or trends between the diseases and lung cancer.")
cat("There is a moderate positive correlation (0.5036) between the prevalence of heart disease and lung cancer. This suggests that counties with higher rates of heart disease tend to have higher rates of lung cancer, and vice versa.")
cat("There is a moderate positive correlation (0.4270) between the prevalence of asthma and lung cancer. This implies that areas with higher rates of asthma tend to have higher rates of lung cancer, and vice versa.")
cat("There is a moderate positive correlation (0.4586) between the prevalence of diabetes and lung cancer. Counties with higher rates of diabetes also tend to have higher rates of lung cancer, and vice versa.")
cat("In summary, all three diseases (heart disease, asthma, and diabetes) show a moderate positive correlation with lung cancer. This means that as the prevalence of these diseases increases, there tends to be an increase in the prevalence of lung cancer in the given counties.")

#==================================================================================================

health_ins <- read.csv("county_noHealthIns_perc_pop_2018_2019.csv")

# Merge datasets
merged_data6 <- inner_join(health_ins, lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Plot the relationship with a bar plot
ggplot(merged_data6, aes(x = cut(Value.x, breaks = 10), y = Value.y, fill = cut(Value.x, breaks = 10))) +
  geom_bar(stat = "summary", fun = "mean") +
  labs(title = "Relationship Between Health Insurance Coverage and Average Lung Cancer Rates",
       x = "Percentage of Population with No Health Insurance",
       y = "Average Lung Cancer Incidence Rate",
       fill = "Health Insurance Coverage") +
  theme_minimal()

# Convert columns to numeric
merged_data6$Value.x <- as.numeric(as.character(merged_data6$Value.x))
merged_data6$Value.y <- as.numeric(as.character(merged_data6$Value.y))

# Calculate correlation coefficient
correlation <- cor(merged_data6$Value.x, merged_data6$Value.y, use = "complete.obs")

# Print correlation coefficient
cat("Correlation between Health Insurance Coverage and Lung Cancer Rates:", correlation, "\n")

# Conclusion
cat("The bar plot illustrates the relationship between the percentage of the population with no health insurance and lung cancer incidence rate across different states.")
cat("The correlation coefficient of", correlation, "indicates the strength and direction of this relationship.")
cat("A positive correlation suggests that areas with higher percentages of uninsured population tend to have higher lung cancer incidence rates, and vice versa.")
cat("This information is crucial for understanding potential healthcare disparities and may guide interventions to improve health insurance coverage and reduce lung cancer rates.")

#==================================================================================================

smoke <- read.csv("smoking_adults_per100k_pop_2018_2019.csv")

# Merge datasets on common columns
merged_data7 <- inner_join(smoke, lung_cancer, by = c("StateFIPS", "CountyFIPS", "County"))

# Remove rows with non-finite or missing values
merged_data7 <- merged_data7[complete.cases(merged_data7$Value.x, merged_data7$Value.y), ]

# Plotting
ggplot(merged_data7, aes(x = Value.x, y = Value.y)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE, color = "red", fill = "green") +
  labs(
    title = "Relationship Between Smoking Rate and Lung Cancer Incidence",
    x = "Smoking Rate",
    y = "Lung Cancer Incidence",
    caption = "Green area represents 95% confidence interval"
  ) +
  theme_minimal()

# Convert columns to numeric
merged_data7$Value.x <- as.numeric(as.character(merged_data7$Value.x))
merged_data7$Value.y <- as.numeric(as.character(merged_data7$Value.y))

# Calculate correlation coefficient
correlation <- cor(merged_data7$Value.x, merged_data7$Value.y, use = "complete.obs")

# Print correlation coefficient
cat("Correlation between Smoking Rate and Lung Cancer Incidence:", correlation, "\n")

# Conclusion
cat("The scatter plot and correlation coefficient suggest a relationship between smoking rate and lung cancer incidence.")
cat("The positive correlation indicates that areas with higher smoking rates tend to have higher lung cancer incidence rates.")
cat("The upward slope of the trendline indicates that there is a positive association between smoking rate and lung cancer incidence. As smoking rates increase, lung cancer incidence tends to increase as well.")
cat("The small size of the confidence interval suggests a relatively high level of precision in estimating the trend.")
cat("This reinforces the well-established link between smoking and lung cancer, emphasizing smoking as a major preventable cause of the disease.")

#==================================================================================================

# Get a map of the US states
us_map <- map_data("state")

# Ensure state names match between datasets
lung_cancer$region <- tolower(lung_cancer$State) 

# Merge lung cancer data with state map data
merged_data8 <- merge(us_map, lung_cancer, by = "region", all.x = TRUE)

# Plotting
ggplot(merged_data8, aes(x = long, y = lat, group = group, fill = Value)) +
  geom_polygon(color = "gray", size = 0.5) +
  scale_fill_gradient(low = "yellow", high = "red", name = "Lung Cancer Patients") +
  labs(title = "Lung Cancer Patients by State") +
  theme_void()

# Find the maximum and minimum values
max_value <- max(lung_cancer$Value, na.rm = TRUE)
min_value <- min(lung_cancer$Value, na.rm = TRUE)

# Find the state(s) corresponding to the maximum and minimum values
state_max <- lung_cancer$State[which.max(lung_cancer$Value)]
state_min <- lung_cancer$State[which.min(lung_cancer$Value)]

# Print the results
cat("Maximum Number of Lung Cancer Patients:", max_value, "in", state_max, "\n")
cat("Minimum Number of Lung Cancer Patients:", min_value, "in", state_min, "\n")

